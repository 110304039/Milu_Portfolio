ALTER TABLE Comment
MODIFY Content varchar(150) NOT NULL;
