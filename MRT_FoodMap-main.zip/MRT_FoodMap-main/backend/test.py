import function_person
import function_event

# print(function_person.register('canddy', '11110098'))
# print(function_person.register('canddy', '11110098'))
# print(function_station.new_event('canddy', "2023-05-22 19:01:00", "romen", "R10"))
print(function_event.successfully_pair("candy", "candyy", "2023-05-22 19:01:00"))