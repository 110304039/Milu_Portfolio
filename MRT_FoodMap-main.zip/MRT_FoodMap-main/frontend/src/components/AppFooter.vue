<template>
    <footer class="footer footer-center p-6 bg-white text-base-content">
      <div>
        <p>Copyright © 2023 - NCCU DBMS Group3  :></p>
      </div>
    </footer>
</template>
<script>
export default {
}
</script>
<style>
</style>
